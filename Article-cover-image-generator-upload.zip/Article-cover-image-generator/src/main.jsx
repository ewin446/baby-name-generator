import React, { useEffect, useMemo, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'

const CATALOG_KEY = 'auto-psi-catalog-v1'
const ORDERS_KEY = 'auto-psi-orders-v1'

const money = (n) => `¥${Number(n).toFixed(2)}`
const nowStamp = () => {
  const d = new Date()
  const pad = (v) => String(v).padStart(2, '0')
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`
}
const genId = () => `ORDER_${nowStamp()}_${Math.random().toString(36).slice(2, 6).toUpperCase()}`

const seedProducts = [
  {
    id: 'p1',
    name: 'ChatGPT Plus 年卡',
    subtitle: '购买后自动发送开通方式与订单详情',
    price: 188,
    compareAt: 228,
    stock: 18,
    sales: 192,
    tag: '热门',
    badge: '即时发货',
    accent: 'violet',
    description: '适合日常写作、资料整理、编程辅助。付款完成后自动发货。',
    features: ['支持支付宝', '自动发货', '订单可查'],
    specs: ['年卡', '月卡'],
  },
  {
    id: 'p2',
    name: 'Gemini Ultra 家庭号',
    subtitle: '稳定套餐，适合长期使用',
    price: 98,
    compareAt: 128,
    stock: 24,
    sales: 87,
    tag: '家庭',
    badge: '稳定供货',
    accent: 'pink',
    description: '支持多设备登录，购买后可直接查看说明与使用步骤。',
    features: ['家庭可用', '多端支持', '自动发货'],
    specs: ['标准版', '高级版'],
  },
  {
    id: 'p3',
    name: 'GPT Pro 月卡会员',
    subtitle: '轻量升级，低成本体验高级能力',
    price: 38,
    compareAt: 58,
    stock: 33,
    sales: 266,
    tag: '热销',
    badge: '秒发',
    accent: 'sky',
    description: '适合先体验再决定是否升级更长期套餐。',
    features: ['下单即发', '可查询', '售后支持'],
    specs: ['30天', '60天'],
  },
  {
    id: 'p4',
    name: 'Gemini Pro 一年订阅卡密',
    subtitle: '一次购买，长期使用',
    price: 216,
    compareAt: 268,
    stock: 12,
    sales: 71,
    tag: '推荐',
    badge: '卡密发货',
    accent: 'mint',
    description: '适合需要稳定长期订阅的用户，支付后自动发出卡密。',
    features: ['卡密发货', '库存可见', '支持补发'],
    specs: ['1年', '2年'],
  },
  {
    id: 'p5',
    name: '会员积分礼包',
    subtitle: '注册即送，购买越多奖励越多',
    price: 9.9,
    compareAt: 19.9,
    stock: 58,
    sales: 705,
    tag: '福利',
    badge: '新用户礼',
    accent: 'amber',
    description: '适合做拉新与复购，积分与优惠券可叠加使用。',
    features: ['积分累计', '邀请奖励', '自动到账'],
    specs: ['基础包', '升级包'],
  },
  {
    id: 'p6',
    name: '美国 Gmail 成品邮箱',
    subtitle: '适合外贸/社媒工具场景',
    price: 24,
    compareAt: 39,
    stock: 30,
    sales: 112,
    tag: '现货',
    badge: '库存充足',
    accent: 'rose',
    description: '付款后自动发货，支持订单号、联系方式查询。',
    features: ['自动发货', '售后补发', '订单查询'],
    specs: ['单号', '批量'],
  },
  {
    id: 'p7',
    name: '三个月链接兑换包',
    subtitle: '短期试用/活动促销首选',
    price: 66,
    compareAt: 88,
    stock: 41,
    sales: 159,
    tag: '限时',
    badge: '快速交付',
    accent: 'indigo',
    description: '适合短期活动、试用、体验版和新手上手。',
    features: ['低门槛', '快速交付', '可续费'],
    specs: ['3个月', '6个月'],
  },
  {
    id: 'p8',
    name: '企业批量开通包',
    subtitle: '大客户批量下单，自动生成订单',
    price: 499,
    compareAt: 599,
    stock: 9,
    sales: 28,
    tag: '企业',
    badge: '大单优惠',
    accent: 'slate',
    description: '适合代理、工作室、团队批量采购场景。',
    features: ['批量下单', '专属客服', '发票支持'],
    specs: ['10单起', '50单起'],
  },
]

const initialOrders = () => {
  try {
    const raw = localStorage.getItem(ORDERS_KEY)
    if (raw) return JSON.parse(raw)
  } catch {}
  return [
    {
      id: 'ORDER_20260001',
      name: '王先生',
      contact: '138****2222',
      productId: 'p1',
      productName: 'ChatGPT Plus 年卡',
      amount: 188,
      paymentMethod: '支付宝',
      status: '已完成',
      createdAt: '2026-04-16 10:20',
      note: '已自动发货，订单状态已同步。',
    },
    {
      id: 'ORDER_20260002',
      name: '李女士',
      contact: 'li@example.com',
      productId: 'p4',
      productName: 'Gemini Pro 一年订阅卡密',
      amount: 216,
      paymentMethod: '支付宝',
      status: '已支付',
      createdAt: '2026-04-16 11:02',
      note: '等待发货中，稍后自动完成。',
    },
  ]
}

function App() {
  const [products] = useState(seedProducts)
  const [orders, setOrders] = useState(initialOrders)
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('全部')
  const [selectedProduct, setSelectedProduct] = useState(products[0])
  const [heroMessage, setHeroMessage] = useState('')
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [checkoutForm, setCheckoutForm] = useState({ name: '', contact: '', quantity: 1, method: '支付宝', note: '' })
  const [query, setQuery] = useState('')
  const [queryResult, setQueryResult] = useState(null)
  const productsRef = useRef(null)
  const ordersRef = useRef(null)
  const memberRef = useRef(null)

  useEffect(() => {
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders))
  }, [orders])

  const categories = useMemo(() => ['全部', ...new Set(products.map((p) => p.tag))], [products])
  const visibleProducts = useMemo(() => {
    const q = search.trim().toLowerCase()
    return products.filter((p) => {
      const matchCategory = activeCategory === '全部' || p.tag === activeCategory
      const matchSearch = !q || [p.name, p.subtitle, p.description, p.tag].some((item) => item.toLowerCase().includes(q))
      return matchCategory && matchSearch
    })
  }, [products, activeCategory, search])

  const stats = useMemo(() => ({
    products: products.length,
    buyNow: products.filter((p) => p.stock > 0).length,
    inventory: products.reduce((sum, p) => sum + p.stock, 0),
    sales: products.reduce((sum, p) => sum + p.sales, 0),
  }), [products])

  const handleBuy = (product) => {
    setSelectedProduct(product)
    setCheckoutForm((prev) => ({ ...prev, note: `想购买：${product.name}` }))
    setCheckoutOpen(true)
    setHeroMessage(`已选择「${product.name}」，请填写订单信息。`)
  }

  const handleCreateOrder = (e) => {
    e.preventDefault()
    const order = {
      id: genId(),
      name: checkoutForm.name || '匿名用户',
      contact: checkoutForm.contact || '未填写',
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      amount: Number((selectedProduct.price * Number(checkoutForm.quantity || 1)).toFixed(2)),
      paymentMethod: checkoutForm.method,
      status: '待支付',
      createdAt: new Date().toLocaleString('zh-CN', { hour12: false }),
      note: checkoutForm.note || '等待支付后自动发货',
    }
    setOrders((prev) => [order, ...prev])
    setQuery(order.id)
    setQueryResult(order)
    setCheckoutOpen(false)
    setHeroMessage(`订单 ${order.id} 已生成，支付后将自动发货。`)
    setTimeout(() => ordersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 180)
  }

  const handleQuery = (value) => {
    const term = value.trim().toLowerCase()
    if (!term) {
      setQueryResult(null)
      return
    }
    const found = orders.find((o) => o.id.toLowerCase().includes(term) || String(o.contact).toLowerCase().includes(term) || o.productName.toLowerCase().includes(term))
    setQueryResult(found || { notFound: true, term })
  }

  const loadDemo = () => {
    setHeroMessage('已加载示例商品与订单信息。')
    setSearch('')
    setActiveCategory('全部')
  }

  const markPaid = (id) => {
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status: '已支付', note: '已付款，等待自动发货。' } : o)))
    setHeroMessage(`订单 ${id} 已手动标记为已支付。`)
  }

  return (
    <div className="page-shell">
      <div className="ambient ambient-a" />
      <div className="ambient ambient-b" />

      <header className="topbar">
        <a className="brand" href="#top">
          <span className="brand-mark">⚡</span>
          <span>自动发货商店</span>
        </a>
        <nav className="navlinks">
          <a href="#top">首页</a>
          <a href="#member">会员中心</a>
          <a href="#orders">订单查询</a>
        </nav>
      </header>

      <main id="top" className="main-wrap">
        <section className="hero-card">
          <div className="hero-copy">
            <span className="pill">精选数字商品</span>
            <h1>付款后自动发货，省时省心，买完即可使用。</h1>
            <p className="hero-text">
              适合卡密、会员、账号、订阅等虚拟商品。支持支付宝支付回调、订单查询和自动发货流程，
              下单后系统自动处理，不需要人工盯单。
            </p>

            <div className="cta-row">
              <button className="btn primary" onClick={() => productsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
                开始选购
              </button>
              <button className="btn secondary" onClick={() => ordersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
                查看订单
              </button>
              <button className="btn secondary" onClick={() => memberRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
                会员中心
              </button>
            </div>

            <div className="rewards">
              <div>
                <span className="rewards-badge">新用户福利</span>
                <strong>注册即可获得 10 积分，邀请好友再得奖励。</strong>
              </div>
              <div className="rewards-grid">
                <div><span>注册礼</span><strong>10 积分</strong></div>
                <div><span>下单返积分</span><strong>+1</strong></div>
                <div><span>邀请好友</span><strong>+1</strong></div>
                <div><span>奖励门槛</span><strong>15 积分</strong></div>
              </div>
            </div>
          </div>

          <div className="hero-stats">
            <div className="stat-card stat-violet"><span>{stats.products}</span><small>上架商品</small></div>
            <div className="stat-card stat-pink"><span>{stats.buyNow}</span><small>可立即购买</small></div>
            <div className="stat-card stat-sky"><span>{stats.inventory}</span><small>当前订单库存</small></div>
            <div className="stat-card stat-mint"><span>{stats.sales}</span><small>累计销量</small></div>
          </div>
        </section>

        {heroMessage ? <div className="notice">{heroMessage}</div> : null}

        <section className="section" ref={productsRef}>
          <div className="section-head">
            <div>
              <span className="section-tag">精选商品</span>
              <h2>热门数字商品，一键下单自动发货</h2>
              <p>模拟同款首页结构，包含商品展示、会员福利和订单查询入口。</p>
            </div>
            <div className="search-panel">
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜索商品名称 / 标签 / 描述" />
              <button className="btn ghost" onClick={loadDemo}>刷新示例</button>
            </div>
          </div>

          <div className="filter-row">
            {categories.map((cat) => (
              <button key={cat} className={cat === activeCategory ? 'chip active' : 'chip'} onClick={() => setActiveCategory(cat)}>
                {cat}
              </button>
            ))}
          </div>

          <div className="product-grid">
            {visibleProducts.map((product) => (
              <article className="product-card" key={product.id}>
                <div className="product-badges">
                  <span className={`badge badge-${product.accent}`}>{product.badge}</span>
                  <span className="badge badge-soft">销量 {product.sales}</span>
                  <span className="badge badge-soft-green">库存 {product.stock}</span>
                </div>
                <h3>{product.name}</h3>
                <p className="subtitle">{product.subtitle}</p>
                <p className="desc">{product.description}</p>
                <div className="specs">
                  {product.features.map((item) => <span key={item}>{item}</span>)}
                </div>
                <div className="product-footer">
                  <div>
                    <small>起步价</small>
                    <strong>{money(product.price)} <s>{money(product.compareAt)}</s></strong>
                  </div>
                  <button className="btn primary small" onClick={() => handleBuy(product)}>立即购买</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="section rules-card">
          <span className="section-tag">购买规则</span>
          <h2>请在下单前确认你理解并接受以下规则。</h2>
          <div className="rules-list">
            <div>1. 数字商品一经发货，不支持无理由退款；如遇异常请先联系人工客服。</div>
            <div>2. 支付成功后自动发货，若订单状态未更新，可在订单查询中重新查看。</div>
            <div>3. 请填写真实联系方式，便于补发、售后和订单找回。</div>
          </div>
        </section>

        <section className="section member-card" id="member" ref={memberRef}>
          <div className="member-left">
            <span className="section-tag">会员福利</span>
            <h2>注册即送积分，购买越多奖励越多。</h2>
            <p>
              会员中心支持积分累计、邀请奖励和权益进度展示。你可以把它作为站点的会员体系入口，
              也可以直接展示账号权益、积分、折扣和邀请任务。
            </p>
            <div className="benefit-grid">
              <div className="mini-card"><strong>注册即领取</strong><span>10 积分</span></div>
              <div className="mini-card"><strong>购买越多</strong><span>返利越高</span></div>
              <div className="mini-card"><strong>邀请好友</strong><span>双向奖励</span></div>
            </div>
          </div>
          <div className="member-right">
            <div className="progress-head">福利进度</div>
            <div className="progress-row"><span>注册赠送</span><strong>10</strong></div>
            <div className="progress-row"><span>达标可领奖励</span><strong>15</strong></div>
            <button className="btn primary full" onClick={() => ordersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
              立即登录查看福利
            </button>
          </div>
        </section>

        <section className="section orders-card" id="orders" ref={ordersRef}>
          <span className="section-tag">订单查询</span>
          <h2>输入订单号，继续查看支付或发货结果。</h2>
          <p>可通过订单号、购买时填写的联系方式或商品名称查询订单状态。</p>
          <div className="query-box">
            <input value={query} onChange={(e) => { setQuery(e.target.value); handleQuery(e.target.value) }} placeholder="请输入订单号，例如 ORDER_2026..." />
            <button className="btn primary" onClick={() => handleQuery(query)}>查看订单</button>
          </div>
          <div className="query-box second">
            <input placeholder="请输入购买时填写的联系方式" onChange={(e) => handleQuery(e.target.value)} />
            <button className="btn secondary" onClick={() => handleQuery(query)}>按照联系方式查询</button>
          </div>

          <div className="order-results">
            {queryResult && !queryResult.notFound ? (
              <div className="order-card-result">
                <div>
                  <strong>{queryResult.id}</strong>
                  <span>{queryResult.productName}</span>
                </div>
                <div className="order-meta">
                  <span>联系人：{queryResult.contact}</span>
                  <span>金额：{money(queryResult.amount)}</span>
                  <span>状态：{queryResult.status}</span>
                  <span>支付方式：{queryResult.paymentMethod}</span>
                </div>
                <button className="btn ghost" onClick={() => markPaid(queryResult.id)}>手动标记已支付</button>
              </div>
            ) : queryResult?.notFound ? (
              <div className="empty-state">未找到订单：{queryResult.term}</div>
            ) : (
              <div className="empty-state">请输入订单号或联系方式进行查询。</div>
            )}
          </div>

          <div className="history-list">
            {orders.slice(0, 4).map((o) => (
              <div className="history-item" key={o.id}>
                <div>
                  <strong>{o.id}</strong>
                  <span>{o.productName}</span>
                </div>
                <div>
                  <span>{o.createdAt}</span>
                  <small>{o.status}</small>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="footer">
        <p>© 2026 自动发货商店 · 支持订单查询、支付回调和到款后自动发货</p>
        <div className="navlinks footer-links">
          <a href="#top">首页</a>
          <a href="#member">会员中心</a>
        </div>
      </footer>

      {checkoutOpen ? (
        <div className="modal-backdrop" onClick={() => setCheckoutOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <div>
                <span className="section-tag">立即购买</span>
                <h3>{selectedProduct.name}</h3>
              </div>
              <button className="close-btn" onClick={() => setCheckoutOpen(false)}>×</button>
            </div>
            <p className="modal-desc">填写信息后生成订单，支付完成后自动发货。</p>
            <form className="checkout-form" onSubmit={handleCreateOrder}>
              <label>
                你的称呼
                <input required value={checkoutForm.name} onChange={(e) => setCheckoutForm((prev) => ({ ...prev, name: e.target.value }))} placeholder="请输入姓名 / 昵称" />
              </label>
              <label>
                联系方式
                <input required value={checkoutForm.contact} onChange={(e) => setCheckoutForm((prev) => ({ ...prev, contact: e.target.value }))} placeholder="手机号 / 邮箱 / Telegram" />
              </label>
              <div className="row-2">
                <label>
                  数量
                  <input type="number" min="1" max="20" value={checkoutForm.quantity} onChange={(e) => setCheckoutForm((prev) => ({ ...prev, quantity: e.target.value }))} />
                </label>
                <label>
                  支付方式
                  <select value={checkoutForm.method} onChange={(e) => setCheckoutForm((prev) => ({ ...prev, method: e.target.value }))}>
                    <option>支付宝</option>
                    <option>微信</option>
                    <option>银行卡</option>
                  </select>
                </label>
              </div>
              <label>
                备注
                <textarea rows="3" value={checkoutForm.note} onChange={(e) => setCheckoutForm((prev) => ({ ...prev, note: e.target.value }))} placeholder="填写额外说明" />
              </label>
              <div className="checkout-total">
                <span>合计</span>
                <strong>{money(selectedProduct.price * Number(checkoutForm.quantity || 1))}</strong>
              </div>
              <button className="btn primary full" type="submit">生成订单并继续支付</button>
            </form>
          </div>
        </div>
      ) : null}
    </div>
  )
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
